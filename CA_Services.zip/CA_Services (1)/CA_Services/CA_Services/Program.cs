using CA_Services.Services;
using CA_Services.Services.Interfaces;
using CA_Services.Data;
using Microsoft.EntityFrameworkCore;
using Pomelo.EntityFrameworkCore.MySql.Infrastructure;

var builder = WebApplication.CreateBuilder(args);
//Adding CORS Policy
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAllOrigins",
        builder =>
        {
            builder.AllowAnyOrigin()
                   .AllowAnyHeader()
                   .AllowAnyMethod();
        });
});

var connectionString = builder.Configuration.GetConnectionString("DefaultConnection");

// Add services to the container.

builder.Services.AddDbContext<ApplicationDBContext>(options =>
    options.UseMySql(
        connectionString,
        new MySqlServerVersion(new Version(8, 0, 40))
    )
);

builder.Services.AddControllers();

builder.Services.AddScoped<IGetRootCertificate, GetRootCertificate>();
builder.Services.AddScoped<IGetIssuerCertificate, GetIssuerCertificate>();
builder.Services.AddScoped<IGenerateEndCertificate, GenerateEndCertificate>();
builder.Services.AddScoped<IGenerateEndCertificateCSR, GenerateEndCertificateCSR>();
builder.Services.AddScoped<IGenerateOcspResp, GenerateOcspResp>();
builder.Services.AddScoped<IRevokeCertificate, RevokeCertificateByRequest>();
builder.Services.AddScoped<ICheckCertificateDetails, CheckCertificateDetails>();

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();
app.UseCors("AllowAllOrigins");

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
